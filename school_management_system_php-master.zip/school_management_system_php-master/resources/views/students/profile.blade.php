@extends('students/base')

@section('title')
    Profile
@endsection

@section('style')
<style>
   
</style>
    
@endsection

@section('body')
<h1>profile page</h1>

@endsection