<!-- 
Assignment Operators: Used to assign values to variables. 
Example: =, +=, -=, *=, /=, %=.
 -->

 <?php
$num1 = 4;
echo "$num1"."<br>";
$num1 += 2;
echo "$num1"."<br>";
$num1 -= 2;
echo "$num1"."<br>";
$num1 *= 2;
echo "$num1"."<br>";
$num1 /= 2;
echo "$num1"."<br>";
$num1 %= 2;
echo "$num1"."<br>";
$num1 **= 2;
echo "$num1"."<br>";
 ?>