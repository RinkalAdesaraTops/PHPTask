<!-- 
Arithmetic Operators: Used to perform mathematical operations such as addition, subtraction, multiplication, division, modulus, and exponentiation. 

Example: +, -, *, /, %, **.
 -->

<?php
$num1 = 4;
$num2 = 2;

$num3 = $num1 + $num2;
echo $num3 . "<br>";
$num4 = $num1 - $num2;
echo $num4. "<br>";
$num5 = $num1 * $num2;
echo $num5. "<br>";
$num6 = $num1 / $num2;
echo $num6. "<br>";
$num7 = $num1 % $num2;
echo $num7. "<br>";
$num8 = $num1 ** $num2;
echo $num8. "<br>"

?>