<?php
echo "This is my first code in php.";
?>