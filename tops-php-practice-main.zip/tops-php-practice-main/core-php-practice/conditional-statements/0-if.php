<!-- 
if Statement: Executes a block of code if a specified condition is true.
 -->
<?php
$age = 18;
if ($age >= 18) {
    echo "You are an adult.";
}

?>
