<!-- 
if...else Statement: Executes one block of code if the condition is true and another block if the condition is false.
 -->

<?php
$age = 16;
if ($age >= 18) {
    echo "You are an adult.";
} else {
    echo "You are a minor.";
}
?>