<!-- 
return: Exits a function and optionally returns a value.
 -->

<?php
function add($a, $b) {
    return $a + $b;
}
$result = add(3, 4); // $result is assigned the value 7
echo $result;

?>