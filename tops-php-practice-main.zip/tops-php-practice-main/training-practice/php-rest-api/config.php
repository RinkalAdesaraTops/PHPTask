<?php 

$conn = mysqli_connect("localhost","root","root","api_crud") or die("Connection Failed");

 ?>