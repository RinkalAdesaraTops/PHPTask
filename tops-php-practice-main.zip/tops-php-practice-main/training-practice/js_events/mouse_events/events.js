function showName(){
    document.write('<p>brijesh gondaliya</p>');
}