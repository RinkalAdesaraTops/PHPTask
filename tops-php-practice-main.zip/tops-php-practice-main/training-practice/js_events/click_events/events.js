function showName(){
    document.write("<p>Brijesh gondaliya</p>");
    alert("brijesh gondaliya");
}