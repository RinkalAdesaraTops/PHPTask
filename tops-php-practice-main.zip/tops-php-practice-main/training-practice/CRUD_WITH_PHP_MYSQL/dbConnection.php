<?php
$conn = mysqli_connect('localhost', 'root', 'root', 'phpcrud');

// if($conn){
//     echo "<script>alert('Database connected successfully. Please click on OK button ')</script>";
// }
?>